# Horizon Academy — School Website

A stunning React website for a middle/high school with 3D particle animations, scroll reveals, and animated stats.

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Start the development server
```bash
npm start
```
Opens at [http://localhost:3000](http://localhost:3000)

### 3. Build for production
```bash
npm run build
```

---

## Project Structure

```
horizon-academy/
├── public/
│   └── index.html
├── src/
│   ├── index.js              # React entry point
│   ├── App.jsx               # Root component
│   ├── styles/
│   │   └── globals.css       # Global styles & animations
│   ├── data/
│   │   └── content.js        # All site text & data (edit here!)
│   ├── hooks/
│   │   ├── useCountUp.js     # Animated number counter
│   │   └── useReveal.js      # Scroll reveal hook
│   └── components/
│       ├── HorizonAcademy.jsx  # Main page layout
│       ├── ParticleCanvas.jsx  # 3D particle animation
│       ├── Navbar.jsx
│       ├── Hero.jsx
│       ├── About.jsx
│       ├── Academics.jsx
│       ├── Facilities.jsx
│       ├── News.jsx
│       ├── Admissions.jsx
│       ├── Contact.jsx
│       └── Footer.jsx
└── package.json
```

---

## Customising Content

All text, icons, and data live in **`src/data/content.js`**. Edit that file to change:
- School name & nav links
- Stats (university acceptance rate, student count, etc.)
- Program cards
- Facility cards
- News articles
- Admissions steps
- Contact info

## Adding Real Photos

Each section has clearly labelled placeholder slots. To replace a placeholder:

**About section** — in `About.jsx`, replace the placeholder div with:
```jsx
<img src="/images/campus.jpg" alt="Campus" />
```

**Facilities** — in `content.js`, add an `imgSrc` field to each facility and update `Facilities.jsx` to render it.

**Hero background** — in `Hero.module.css`, replace the Unsplash URL in `.heroBg` with your own image path.

## Changing the School Name

1. Update the logo text in `Navbar.jsx` and `Footer.jsx`
2. Update the `<title>` in `public/index.html`
3. Update the `<meta name="description">` in `public/index.html`
