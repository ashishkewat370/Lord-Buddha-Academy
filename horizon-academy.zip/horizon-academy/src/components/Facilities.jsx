import useReveal from '../hooks/useReveal';
import { FACILITIES } from '../data/content';
import styles from './Facilities.module.css';

export default function Facilities() {
  const ref = useReveal();
  return (
    <section id="facilities" className={`ha-reveal ${styles.facilities}`} ref={ref}>
      <div className={styles.eyebrow}>Facilities</div>
      <h2 className={styles.heading}>Built for learning<br />and life</h2>
      <p className={styles.sub}>Our campus supports every dimension of student development — academic, athletic, artistic, and social.</p>
      <div className={styles.grid}>
        {FACILITIES.map(f => (
          <div className={styles.card} key={f.title}>
            <div className={styles.imgWrap} style={{ background: f.bg }}>
              {/* Replace contents with: <img src="your-photo.jpg" alt={f.title} /> */}
              <div className={styles.imgIcon}>{f.icon}</div>
              <div className={styles.imgLabel}>{f.label}</div>
            </div>
            <div className={styles.body}>
              <h4>{f.title}</h4>
              <p>{f.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
