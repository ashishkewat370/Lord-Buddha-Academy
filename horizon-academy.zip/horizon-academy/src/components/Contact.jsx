import { useState } from 'react';
import useReveal from '../hooks/useReveal';
import { CONTACT_INFO } from '../data/content';
import styles from './Contact.module.css';

export default function Contact() {
  const ref = useReveal();
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 3000);
    setForm({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <section id="contact" className={`ha-reveal ${styles.contact}`} ref={ref}>
      <div className={styles.eyebrow}>Contact</div>
      <h2 className={styles.heading}>Get in touch</h2>
      <div className={styles.grid}>
        <div className={styles.info}>
          {CONTACT_INFO.map(c => (
            <div className={styles.ci} key={c.label}>
              <div className={styles.ciIco}>{c.icon}</div>
              <div>
                <strong>{c.label}</strong>
                <span>{c.value}</span>
              </div>
            </div>
          ))}
        </div>
        <form className={styles.form} onSubmit={handleSubmit}>
          <input
            type="text" placeholder="Your name" required
            value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
          />
          <input
            type="email" placeholder="Email address" required
            value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
          />
          <input
            type="text" placeholder="Subject"
            value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })}
          />
          <textarea
            placeholder="Your message" rows={5}
            value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}
          />
          <button type="submit" className={styles.submitBtn}>
            {sent ? '✓ Message Sent!' : 'Send Message'}
          </button>
        </form>
      </div>
    </section>
  );
}
