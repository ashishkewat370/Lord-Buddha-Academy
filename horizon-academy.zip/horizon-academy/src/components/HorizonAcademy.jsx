import '../styles/globals.css';
import Navbar from './Navbar';
import Hero from './Hero';
import About from './About';
import Academics from './Academics';
import Facilities from './Facilities';
import News from './News';
import Admissions from './Admissions';
import Contact from './Contact';
import Footer from './Footer';

export default function HorizonAcademy() {
  return (
    <div style={{ fontFamily: "'Inter', system-ui, sans-serif", background: '#050d1a', color: '#fff', overflowX: 'hidden' }}>
      <Navbar />
      <Hero />
      <About />
      <Academics />
      <Facilities />
      <News />
      <Admissions />
      <Contact />
      <Footer />
    </div>
  );
}
