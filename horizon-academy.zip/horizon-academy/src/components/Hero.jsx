import { useState, useEffect } from 'react';
import ParticleCanvas from './ParticleCanvas';
import useCountUp from '../hooks/useCountUp';
import { STATS } from '../data/content';
import styles from './Hero.module.css';

export default function Hero() {
  const [started, setStarted] = useState(false);
  useEffect(() => { setTimeout(() => setStarted(true), 400); }, []);

  const counts = STATS.map(s => useCountUp(s.target, s.suffix, 1500, started));

  return (
    <section className={styles.hero}>
      <div className={styles.heroBg} />
      <div className={styles.heroOverlay} />
      <ParticleCanvas />

      <div className={styles.content}>
        <div className={styles.tag}>
          <span className={styles.pulse} />
          Admissions Open 2026–27
        </div>
        <h1 className={styles.heading}>
          Where Curious Minds Become{' '}
          <span className={styles.gradientText}>Confident Leaders</span>
        </h1>
        <p className={styles.sub}>
          Horizon Academy offers a world-class environment for grades 6–12, blending
          rigorous academics with vibrant co-curricular life.
        </p>
        <div className={styles.btns}>
          <a href="#admissions" className={styles.btnGlow}>Explore Admissions</a>
          <a href="#about" className={styles.btnGhost}>Virtual Tour ↗</a>
        </div>
      </div>

      <div className={styles.statsBar}>
        {STATS.map((s, i) => (
          <div className={styles.stat} key={s.id}>
            <div className={styles.statNum}>{counts[i]}</div>
            <div className={styles.statLbl}>{s.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
