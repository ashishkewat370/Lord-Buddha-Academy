import styles from './Footer.module.css';

const LINKS = ['Privacy Policy', 'Terms of Use', 'Careers', 'Parent Portal'];

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.logo}>✦ Horizon Academy</div>
      <div className={styles.links}>
        {LINKS.map(l => <a key={l} href="#">{l}</a>)}
      </div>
      <div className={styles.copy}>© 2026 Horizon Academy. All rights reserved.</div>
    </footer>
  );
}
