import useReveal from '../hooks/useReveal';
import { ADM_STEPS } from '../data/content';
import styles from './Admissions.module.css';

export default function Admissions() {
  const ref = useReveal();
  return (
    <section id="admissions" className={`ha-reveal ${styles.admissions}`} ref={ref}>
      <div className={styles.glow} />
      <div className={styles.center}>
        <div className={styles.eyebrow}>Admissions</div>
        <h2 className={styles.heading}>Join the Horizon<br />community</h2>
        <p className={styles.sub}>
          We welcome applications from students in grades 6–12. Our process is transparent,
          supportive, and designed to find the right fit.
        </p>
      </div>
      <div className={styles.grid}>
        {ADM_STEPS.map(s => (
          <div className={styles.step} key={s.num}>
            <div className={styles.num}>{s.num}</div>
            <h4>{s.title}</h4>
            <p>{s.desc}</p>
          </div>
        ))}
      </div>
      <div className={styles.cta}>
        <a href="#contact" className={styles.btnGlow}>Start Your Application →</a>
      </div>
    </section>
  );
}
