import useReveal from '../hooks/useReveal';
import { NEWS } from '../data/content';
import styles from './News.module.css';

export default function News() {
  const ref = useReveal();
  return (
    <section id="news" className={`ha-reveal ${styles.news}`} ref={ref}>
      <div className={styles.eyebrow}>News & Events</div>
      <h2 className={styles.heading}>What's happening<br />at Horizon</h2>
      <div className={styles.grid}>
        {NEWS.map(n => (
          <div className={styles.card} key={n.title}>
            <div className={styles.imgWrap} style={{ background: n.bg }}>
              {/* Replace with: <img src="your-news-photo.jpg" alt={n.title} /> */}
              <span style={{ fontSize: 28, opacity: 0.25 }}>{n.icon}</span>
            </div>
            <div className={styles.body}>
              <span className={styles.tag}>{n.tag}</span>
              <h4>{n.title}</h4>
              <p>{n.desc}</p>
              <div className={styles.date}>{n.date}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
