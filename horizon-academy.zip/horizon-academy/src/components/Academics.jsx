import useReveal from '../hooks/useReveal';
import { PROGRAMS } from '../data/content';
import styles from './Academics.module.css';

export default function Academics() {
  const ref = useReveal();
  return (
    <section id="academics" className={`ha-reveal ${styles.academics}`} ref={ref}>
      <div className={styles.eyebrow}>Academics</div>
      <h2 className={styles.heading}>Programs that stretch<br />every student</h2>
      <p className={styles.sub}>From STEM to the arts, our faculty bring deep expertise and genuine passion to every classroom.</p>
      <div className={styles.grid}>
        {PROGRAMS.map(p => (
          <div className={styles.card} key={p.title}>
            <div className={styles.icon}>{p.icon}</div>
            <h3>{p.title}</h3>
            <p>{p.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
