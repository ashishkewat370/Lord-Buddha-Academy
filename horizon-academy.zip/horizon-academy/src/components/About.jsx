import useReveal from '../hooks/useReveal';
import { VALUES } from '../data/content';
import styles from './About.module.css';

export default function About() {
  const ref = useReveal();
  return (
    <section id="about" className={`ha-reveal ${styles.about}`} ref={ref}>
      <div className={styles.eyebrow}>About Us</div>
      <div className={styles.inner}>
        <div className={styles.imgWrap}>
          <div className={styles.imgFrame}>
            {/* Replace the div below with: <img src="your-campus-photo.jpg" alt="Campus" /> */}
            <div className={styles.imgPlaceholder}>
              <span style={{ fontSize: 40, opacity: 0.2 }}>🏫</span>
              <span className={styles.imgHint}>Replace with your school<br />campus photo</span>
            </div>
          </div>
          <div className={styles.badge}>
            <div className={styles.badgeNum}>38</div>
            <div className={styles.badgeLbl}>Years of Excellence</div>
          </div>
        </div>
        <div>
          <h2 className={styles.heading}>Built on curiosity,<br />driven by character</h2>
          <p className={styles.sub}>
            Founded in 1987, Horizon Academy has been shaping young minds for over three
            decades with a commitment to academic excellence and holistic growth.
          </p>
          <div className={styles.values}>
            {VALUES.map(v => (
              <div className={styles.val} key={v.title}>
                <div className={styles.valIcon}>{v.icon}</div>
                <div>
                  <div className={styles.valTitle}>{v.title}</div>
                  <div className={styles.valDesc}>{v.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
