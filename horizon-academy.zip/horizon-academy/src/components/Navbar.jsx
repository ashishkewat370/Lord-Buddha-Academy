import { NAV_LINKS } from '../data/content';
import styles from './Navbar.module.css';

export default function Navbar() {
  return (
    <nav className={styles.nav}>
      <div className={styles.logo}>✦ Horizon Academy</div>
      <div className={styles.links}>
        {NAV_LINKS.map(link => (
          <a key={link} href={`#${link.toLowerCase()}`}>{link}</a>
        ))}
      </div>
      <a href="#admissions" className={styles.cta}>Apply Now →</a>
    </nav>
  );
}
