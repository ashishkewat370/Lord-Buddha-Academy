import { useState, useEffect } from 'react';

export default function useCountUp(target, suffix, duration, start) {
  const [value, setValue] = useState('0' + suffix);

  useEffect(() => {
    if (!start) return;
    let current = 0;
    const step = target / 60;
    const interval = setInterval(() => {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(interval);
      }
      setValue(Math.round(current) + suffix);
    }, duration / 60);
    return () => clearInterval(interval);
  }, [start, target, suffix, duration]);

  return value;
}
