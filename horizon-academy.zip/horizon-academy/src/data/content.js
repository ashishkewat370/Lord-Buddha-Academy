export const NAV_LINKS = ['About', 'Academics', 'Facilities', 'News', 'Admissions'];

export const STATS = [
  { id: 's1', target: 98, suffix: '%', label: 'University acceptance' },
  { id: 's2', target: 1200, suffix: '', label: 'Students enrolled' },
  { id: 's3', target: 40, suffix: '+', label: 'Clubs & activities' },
  { id: 's4', target: 38, suffix: '', label: 'Years of excellence' },
];

export const VALUES = [
  { icon: '🎯', title: 'Academic Excellence', desc: 'Rigorous curriculum aligned with international standards' },
  { icon: '🌱', title: 'Holistic Development', desc: 'Sports, arts, and co-curriculars alongside academics' },
  { icon: '🤝', title: 'Inclusive Culture', desc: 'A diverse, welcoming community for every learner' },
];

export const PROGRAMS = [
  { icon: '🔬', title: 'Science & Technology', desc: 'Hands-on labs, coding workshops, and robotics competitions.' },
  { icon: '📐', title: 'Mathematics', desc: 'From foundational skills to advanced calculus and statistics.' },
  { icon: '📚', title: 'Humanities & Languages', desc: 'Literature, history, and three modern languages offered.' },
  { icon: '🎨', title: 'Creative Arts', desc: 'Music, drama, visual arts, and a dedicated performance stage.' },
  { icon: '🌍', title: 'Social Studies', desc: 'Civics, economics, geography, and current global affairs.' },
  { icon: '🏃', title: 'Physical Education', desc: 'Athletics, yoga, team sports, and wellness education.' },
];

export const FACILITIES = [
  { icon: '🔬', label: 'Add science lab photo', bg: 'linear-gradient(135deg,#0a2040,#1a3a6a)', title: 'Science Labs', desc: 'Six fully equipped labs for biology, chemistry, and physics.' },
  { icon: '📖', label: 'Add library photo', bg: 'linear-gradient(135deg,#0a2830,#1a4a5a)', title: 'Library & Media Centre', desc: '30,000+ volumes, e-resources, and quiet study pods.' },
  { icon: '🏊', label: 'Add sports complex photo', bg: 'linear-gradient(135deg,#1a1a0a,#3a3010)', title: 'Multi-sport Complex', desc: 'Courts, 400m track, swimming pool, and cricket nets.' },
  { icon: '🎭', label: 'Add auditorium photo', bg: 'linear-gradient(135deg,#0a1a0a,#1a3a1a)', title: 'Performing Arts Hall', desc: '600-seat auditorium for recitals, plays, and annual day.' },
  { icon: '💻', label: 'Add tech hub photo', bg: 'linear-gradient(135deg,#1a0a2a,#2a1a4a)', title: 'Technology & Innovation Hub', desc: 'Maker spaces, 3D printers, and a coding lab with 80 stations.' },
  { icon: '🍽️', label: 'Add cafeteria photo', bg: 'linear-gradient(135deg,#1a0a0a,#3a1a1a)', title: 'Student Cafeteria', desc: 'Nutritionist-designed menus with diverse dietary options.' },
];

export const NEWS = [
  { icon: '🏆', bg: 'linear-gradient(135deg,#0a2040,#1a3a6a)', tag: 'Achievement', title: 'Horizon wins national science olympiad for the third year', desc: 'Our Grade 11 team brought home gold in Biology and Physics categories.', date: 'June 2, 2026' },
  { icon: '🎉', bg: 'linear-gradient(135deg,#1a1a0a,#3a3010)', tag: 'Event', title: 'Annual Day 2026 "Horizons Unlimited" set for July 18', desc: 'Performances, project exhibitions, and senior class graduation ceremony.', date: 'May 28, 2026' },
  { icon: '📝', bg: 'linear-gradient(135deg,#0a1a30,#1a3050)', tag: 'Admissions', title: 'Applications for 2026–27 are now open', desc: 'Attend our Open House on June 28 to tour the campus and meet faculty.', date: 'May 20, 2026' },
];

export const ADM_STEPS = [
  { num: '01', title: 'Submit enquiry', desc: 'Fill the online form — our team responds within 48 hours.' },
  { num: '02', title: 'Campus visit', desc: 'Attend an Open House or book a private tour.' },
  { num: '03', title: 'Assessment', desc: 'A short written test and informal faculty interview.' },
  { num: '04', title: 'Offer & enrolment', desc: 'Successful applicants receive a formal offer online.' },
];

export const CONTACT_INFO = [
  { icon: '📍', label: 'Address', value: '12 Horizon Way, Sector 7, New Delhi 110001' },
  { icon: '📞', label: 'Phone', value: '+91 11 2345 6789' },
  { icon: '✉️', label: 'Email', value: 'admissions@horizonacademy.edu.in' },
  { icon: '🕐', label: 'Office Hours', value: 'Mon–Fri: 8:00 AM – 4:00 PM' },
];
