import HorizonAcademy from './components/HorizonAcademy';

export default function App() {
  return <HorizonAcademy />;
}
